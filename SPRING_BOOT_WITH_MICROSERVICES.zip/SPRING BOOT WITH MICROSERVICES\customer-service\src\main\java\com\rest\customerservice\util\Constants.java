package com.rest.customerservice.util;

public class Constants {

	public static final String BASE_URL="http://localhost:8080";
}
